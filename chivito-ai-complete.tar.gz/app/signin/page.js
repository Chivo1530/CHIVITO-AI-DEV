import AuthForm from '../../components/AuthForm'

export default function SignInPage() {
  return <AuthForm mode="signin" />
}